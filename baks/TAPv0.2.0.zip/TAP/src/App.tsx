import { useState, useEffect } from 'react';
import { TheMirror } from './components/TheMirror';
import { DebtLedger } from './components/DebtLedger';
import { TerminalSetup } from './components/TerminalSetup';

function App() {
    const [isSetup, setIsSetup] = useState(false);

    useEffect(() => {
        // Verificar si ya existe una fecha guardada
        const savedDate = localStorage.getItem('tap_birthdate');
        if (savedDate) {
            setIsSetup(true);
        }
    }, []);

    const handleSetupComplete = (date: string) => {
        localStorage.setItem('tap_birthdate', date);
        setIsSetup(true);
    };

    return (
        <div className="min-h-screen bg-black text-terminal-green p-4 md:p-8 font-mono selection:bg-terminal-green selection:text-black">
            {!isSetup ? (
                <TerminalSetup onComplete={handleSetupComplete} />
            ) : (
                <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in zoom-in duration-500">
                    {/* Header */}
                    <header className="flex justify-between items-end border-b border-gray-800 pb-4">
                        <div>
                            <h1 className="text-3xl font-bold tracking-tighter text-white">
                                T.A.P. <span className="text-terminal-green text-sm align-top">v0.2.1</span>
                            </h1>
                            <p className="text-xs text-gray-500 uppercase tracking-[0.2em]">The Abyss Protocol</p>
                        </div>
                        <div className="text-right">
                            <div className="text-xs text-chaos-orange animate-pulse">● SYSTEM ONLINE</div>
                            <div className="text-[10px] text-gray-600">Wai-L // .ALMA-STATE</div>
                        </div>
                    </header>

                    <main className="space-y-12">
                        <section><TheMirror /></section>
                        <section><DebtLedger /></section>
                    </main>

                    <footer className="text-center text-[10px] text-gray-700 mt-20 pb-8">
                        <p>MEMORIA_SAGRADA_ENABLED // NO_DOPAMINE_ALLOWED</p>
                    </footer>
                </div>
            )}
        </div>
    );
}

export default App;