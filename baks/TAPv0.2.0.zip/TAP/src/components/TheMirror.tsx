import { useState, useEffect } from 'react';
import { calculateTimeStats, type TimeStats } from '../utils/timeCalculations';

export function TheMirror() {
    const [stats, setStats] = useState<TimeStats | null>(null);

    // 1. RECUPERAR EL ORIGEN (Fecha Real)
    // Buscamos en localStorage, si no está, usamos la fecha Wai-L por defecto (pero a las 00:00)
    const [birthDate] = useState<Date>(() => {
        const saved = localStorage.getItem('tap_birthdate');
        // Default Wai-L: 25 Junio 1991, pero ahora esperamos que el usuario defina la hora en el Setup
        return saved ? new Date(saved) : new Date('1991-06-25T00:00:00');
    });

    // Estado para el input diario (LocalStorage separado)
    const [dailyInput, setDailyInput] = useState(() => {
        const saved = localStorage.getItem('tap_daily_state');
        return saved ? JSON.parse(saved) : {
            flowHours: 0,
            chaosHours: 0,
            grindHours: 0,
            notes: ''
        };
    });

    useEffect(() => {
        const timer = setInterval(() => {
            setStats(calculateTimeStats(birthDate));
        }, 1000); // Actualización cada segundo para ver los segundos caer

        return () => clearInterval(timer);
    }, [birthDate]);

    // ... (El resto del código de inputs y renderizado se mantiene igual)
    // ... (Solo asegúrate de que el renderizado usa 'stats' como antes)

    useEffect(() => {
        localStorage.setItem('tap_daily_state', JSON.stringify(dailyInput));
    }, [dailyInput]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setDailyInput((prev: any) => ({
            ...prev,
            [name]: name === 'notes' ? value : Number(value)
        }));
    };

    if (!stats) return <div className="text-terminal-green animate-pulse">SYNCING_TEMPORAL_ORIGIN...</div>;

    // Cálculos visuales
    const totalTracked = dailyInput.flowHours + dailyInput.chaosHours + dailyInput.grindHours;
    const sleepAssumed = 7;
    const unaccounted = 24 - sleepAssumed - totalTracked;

    return (
        <div className="space-y-8 font-mono">
            {/* SECCIÓN 1: TIEMPO VIVIDO */}
            <div className="border border-terminal-green/30 p-6 bg-black/50 backdrop-blur-sm relative overflow-hidden group hover:border-terminal-green/50 transition-colors">
                <div className="absolute top-0 right-0 p-2 opacity-50 text-xs text-terminal-green">
                    [ORIGIN: {birthDate.toLocaleDateString()} {birthDate.toLocaleTimeString()}]
                </div>

                <h2 className="text-2xl mb-6 text-terminal-green font-bold tracking-wider glitch-text">
                    THE MIRROR v2.0
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                        <p className="text-gray-400 text-sm uppercase tracking-widest">Tiempo Vivido (Precisión Absoluta)</p>
                        <p className="text-3xl md:text-4xl text-white font-bold tabular-nums">
                            {stats.years}a {stats.months}m {stats.days}d
                        </p>
                        <p className="text-xl text-terminal-green/80 tabular-nums">
                            {stats.hours}h {stats.minutes}m <span className="text-terminal-green animate-pulse">{stats.seconds}s</span>
                        </p>
                    </div>

                    <div className="space-y-4">
                        <div className="bg-gray-900/50 p-4 border-l-2 border-chaos-orange">
                            <p className="text-xs text-chaos-orange mb-1">MORTALIDAD_CHECK</p>
                            <p className="text-white text-lg">
                                Has vivido aprox <span className="text-terminal-green font-bold">{Math.floor(stats.totalDays / 7)}</span> semanas.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* SECCIÓN 2: INPUTS (Igual que antes...) */}
            <div className="border border-chaos-orange/30 p-6 bg-black/50 relative">
                <h3 className="text-xl text-chaos-orange mb-4 flex items-center gap-2">
                    <span>⚡</span> REGISTRO DIARIO
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="space-y-2">
                        <label className="text-xs text-gray-400 uppercase">GRIND (Deber)</label>
                        <input
                            type="number"
                            name="grindHours"
                            value={dailyInput.grindHours}
                            onChange={handleInputChange}
                            className="w-full bg-black border border-gray-700 text-white p-3 focus:border-white focus:outline-none text-xl text-center"
                            min="0" max="24"
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs text-terminal-green uppercase">FLOW (Crear)</label>
                        <input
                            type="number"
                            name="flowHours"
                            value={dailyInput.flowHours}
                            onChange={handleInputChange}
                            className="w-full bg-black border border-terminal-green text-terminal-green p-3 focus:border-white focus:outline-none text-xl text-center shadow-[0_0_10px_rgba(0,255,0,0.1)]"
                            min="0" max="24"
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs text-chaos-orange uppercase">CHAOS (Perder)</label>
                        <input
                            type="number"
                            name="chaosHours"
                            value={dailyInput.chaosHours}
                            onChange={handleInputChange}
                            className="w-full bg-black border border-chaos-orange text-chaos-orange p-3 focus:border-white focus:outline-none text-xl text-center"
                            min="0" max="24"
                        />
                    </div>
                </div>

                {/* Visualizador del Día */}
                <div className="h-4 bg-gray-900 w-full flex rounded-full overflow-hidden mb-6 border border-gray-800">
                    <div style={{ width: `${(sleepAssumed / 24) * 100}%` }} className="bg-blue-900/30" title="Sueño (7h)" />
                    <div style={{ width: `${(dailyInput.grindHours / 24) * 100}%` }} className="bg-gray-600" title="Grind" />
                    <div style={{ width: `${(dailyInput.flowHours / 24) * 100}%` }} className="bg-terminal-green" title="Flow" />
                    <div style={{ width: `${(dailyInput.chaosHours / 24) * 100}%` }} className="bg-chaos-orange" title="Chaos" />
                </div>

                <div className="mt-6 pt-6 border-t border-gray-800 text-center">
                    {unaccounted < 0 ? (
                        <span className="text-alert-red font-bold animate-pulse">⚠️ ERROR DE TIEMPO</span>
                    ) : (
                        <span className="text-gray-500">
                            Horas sin registrar: <span className="text-white font-bold">{unaccounted.toFixed(1)}h</span>
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
}